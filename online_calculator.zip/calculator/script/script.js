let data = "";

let buttons = document.querySelectorAll(".btn");

Array.from(buttons).forEach((button) => {
    button.addEventListener("click", (event)=> {
        if (event.target.innerHTML == "=") {
            for (let temp of data){
                if (temp == "l") {
                    let i = data.indexOf(temp);
                    data = Math.log10(data[i+4]);
                    document.querySelector(".display").value = data;
                }
                else {
                    data = eval(data);
                    document.querySelector(".display").value = data;
                }
            }
        }
        else if (event.target.innerHTML == "log") {
            data = event.target.innerHTML + "(";
            document.querySelector(".display").value = data;
        }
        else if (event.target.innerHTML == "1/x") {
            data = 1/data;
            document.querySelector(".display").value = data;
        }
        else if (event.target.innerHTML == "√") {
            data = Math.pow(data,0.5);
            document.querySelector(".display").value = data;
        }
        else if (event.target.innerHTML == "x<sup>2</sup>") {
            data = Math.pow(data,2);
            document.querySelector(".display").value = data;
        }
        else if (event.target.innerHTML == "DEL") {
            data = data.slice(0, -1);
            document.querySelector(".display").value = data;
        }
        else if (event.target.innerHTML == "C") {
            data = ""
            document.querySelector(".display").value = data;
        }
        else {
            data = data + event.target.innerHTML;
            document.querySelector(".display").value = data;
        }
    })
})